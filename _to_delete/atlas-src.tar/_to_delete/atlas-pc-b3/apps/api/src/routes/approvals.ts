import type { FastifyInstance } from "fastify";
import { AtlasError, approvalRequestStatusSchema } from "@atlas/shared";
import { authorizeEntityAction } from "@atlas/agent-core";
import { z } from "zod";
import { requireAdmin } from "../middleware/auth-guards.js";
import {
  decideApprovalRequest,
  getApprovalRequest,
  listApprovalRequests,
} from "../services/approvals.js";

const listQuerySchema = z.object({
  status: approvalRequestStatusSchema.optional(),
});

const decideBodySchema = z.object({
  approve: z.boolean(),
  reason: z.string().trim().min(1, "reason is required"),
});

export async function registerApprovalRoutes(app: FastifyInstance): Promise<void> {
  app.get("/api/v1/approvals", async (request) => {
    await requireAdmin(app, request);
    const query = listQuerySchema.parse(request.query ?? {});
    const items = listApprovalRequests(query.status);
    return { items };
  });

  app.get("/api/v1/approvals/:id", async (request) => {
    await requireAdmin(app, request);
    const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
    const item = getApprovalRequest(id);
    if (!item) {
      throw new AtlasError("NOT_FOUND", `Approval request ${id} not found`, {
        statusCode: 404,
      });
    }
    return item;
  });

  app.post("/api/v1/approvals/:id/decide", async (request) => {
    const user = await requireAdmin(app, request);
    // ENTITY-LEVEL gate independent of the `requireAdmin` ROLE-LEVEL gate:
    // deciding a pending approval request is itself a control-plane action
    // (CONFIGURATION.EXECUTE) — same pattern as `plugins.ts`. Note this is
    // deliberately `mode: "WRITE"`, not `"APPROVE"` — `authorizeEntityAction`
    // treats `"APPROVE"` as a distinct human-gate mode that always DENIES,
    // reserved for describing an *agent's* attempted self-approval, not
    // this admin HTTP endpoint (which IS the human gate).
    const entityAuthz = authorizeEntityAction("CONFIGURATION", "EXECUTE", {
      mode: "WRITE",
      writeGateOpen: true,
      approved: true,
    });
    if (entityAuthz.decision !== "ALLOWED") {
      const reason =
        entityAuthz.decision === "DENIED"
          ? entityAuthz.reason
          : "approvals.decide (CONFIGURATION.EXECUTE) was not ALLOWED.";
      throw new AtlasError("FORBIDDEN", reason, { statusCode: 403 });
    }
    const { id } = z.object({ id: z.string().uuid() }).parse(request.params);
    const body = decideBodySchema.parse(request.body);
    const updated = decideApprovalRequest(id, {
      decidedBy: user.id,
      approve: body.approve,
      decisionReason: body.reason,
    });
    return updated;
  });
}
