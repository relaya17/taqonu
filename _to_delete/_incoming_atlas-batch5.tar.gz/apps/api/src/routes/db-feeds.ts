import type { FastifyInstance } from "fastify";
import { AtlasError, parseEvidenceRecord, uuidSchema } from "@atlas/shared";
import {
  summarizeSupabaseFeed,
  supabaseFeedInputSchema,
} from "@atlas/integrations-supabase";
import {
  summarizeMongoFeed,
  mongoFeedInputSchema,
} from "@atlas/integrations-mongodb";
import { z } from "zod";
import { authorizeEntityAction } from "@atlas/agent-core";
import { osStore } from "../store/os-store.js";
import { runStateReconciliation } from "../services/state-reconciliation.js";
import { resolveCloudIdentity } from "../services/cloud-identity.js";
import {
  assertProjectReadAccess,
  assertProjectWriteAccess,
} from "../services/project-access.js";

/**
 * ENTITY-LEVEL gate for the 2 feed-registration routes below — registering a
 * DB feed is a CONFIGURATION change (same category as `connections.ts`'s
 * connect/import routes). Self-approved signed-in-human-write pattern used
 * across this round.
 */
function enforceDbFeedEntityAuthz(routeLabel: string): void {
  const entityAuthz = authorizeEntityAction("CONFIGURATION", "CREATE", {
    mode: "WRITE",
    writeGateOpen: true,
    approved: true,
  });
  if (entityAuthz.decision !== "ALLOWED") {
    const reason =
      entityAuthz.decision === "DENIED"
        ? entityAuthz.reason
        : `${routeLabel} (CONFIGURATION.CREATE) was not ALLOWED.`;
    throw new AtlasError("FORBIDDEN", reason, { statusCode: 403 });
  }
}

/**
 * Customer Mongo/Supabase as **observation feeds** → DATABASE evidence.
 * Never accepts connection secrets; Atlas app DB is separate (osStore / optional Supabase).
 */
export async function registerDbFeedRoutes(app: FastifyInstance): Promise<void> {
  app.post("/api/v1/feeds/supabase", async (request, reply) => {
    const body = supabaseFeedInputSchema.parse(request.body);
    await assertProjectWriteAccess(app, request, body.projectId);
    enforceDbFeedEntityAuthz("feeds.supabase");
    const { ownerId } = await resolveCloudIdentity(app, request);
    const summarized = summarizeSupabaseFeed(body);
    const now = new Date().toISOString();

    osStore.setDbFeed(body.projectId, {
      provider: "supabase",
      projectId: body.projectId,
      observedAt: now,
      summary: summarized.summary,
      tableOrCollectionCount: summarized.tableCount,
      names: summarized.names,
      rlsEnabled: body.rlsEnabled ?? null,
      host: body.hostLabel,
    });

    const evidence = parseEvidenceRecord({
      id: crypto.randomUUID(),
      ownerId,
      projectId: body.projectId,
      source: `supabase:${body.hostLabel}`,
      sourceType: "CONNECTOR",
      sourceId: body.hostLabel,
      uri: null,
      excerpt: summarized.summary,
      version: null,
      observedAt: now,
      createdAt: now,
      confidence: 1,
      epistemicState: "FACT",
      category: "DATABASE",
      metadata: {
        schema: body.schemaName,
        tableCount: summarized.tableCount,
        rlsEnabled: body.rlsEnabled ?? null,
        feedRole: "customer_observation_not_atlas_primary",
      },
    });
    osStore.addEvidence(body.projectId, [evidence]);

    const snapshot = runStateReconciliation(body.projectId);
    return reply.status(201).send({
      feed: summarized,
      evidenceId: evidence.id,
      snapshot,
      note: "Customer Supabase metadata only — not Atlas primary store; no secrets accepted.",
    });
  });

  app.post("/api/v1/feeds/mongodb", async (request, reply) => {
    const body = mongoFeedInputSchema.parse(request.body);
    await assertProjectWriteAccess(app, request, body.projectId);
    enforceDbFeedEntityAuthz("feeds.mongodb");
    const { ownerId } = await resolveCloudIdentity(app, request);
    const summarized = summarizeMongoFeed(body);
    const now = new Date().toISOString();

    osStore.setDbFeed(body.projectId, {
      provider: "mongodb",
      projectId: body.projectId,
      observedAt: now,
      summary: summarized.summary,
      tableOrCollectionCount: summarized.collectionCount,
      names: summarized.names,
      rlsEnabled: null,
      host: body.hostLabel,
    });

    const evidence = parseEvidenceRecord({
      id: crypto.randomUUID(),
      ownerId,
      projectId: body.projectId,
      source: `mongodb:${body.hostLabel}/${body.databaseName}`,
      sourceType: "CONNECTOR",
      sourceId: body.databaseName,
      uri: null,
      excerpt: summarized.summary,
      version: null,
      observedAt: now,
      createdAt: now,
      confidence: 1,
      epistemicState: "FACT",
      category: "DATABASE",
      metadata: {
        collectionCount: summarized.collectionCount,
        indexCount: body.indexCount ?? null,
        feedRole: "customer_observation_not_atlas_primary",
      },
    });
    osStore.addEvidence(body.projectId, [evidence]);

    const snapshot = runStateReconciliation(body.projectId);
    return reply.status(201).send({
      feed: summarized,
      evidenceId: evidence.id,
      snapshot,
      note: "Customer MongoDB metadata only — not Atlas primary store; no secrets accepted.",
    });
  });

  app.get("/api/v1/feeds/:projectId", async (request) => {
    // SECURITY FIX (found while widening Policy Engine coverage): this
    // route had ZERO auth — anyone who knew (or scanned) a project id could
    // read its DB schema names, table/collection counts, and deployment
    // feed data. Standard project-scoped read gate.
    const params = z.object({ projectId: uuidSchema }).parse(request.params);
    await assertProjectReadAccess(app, request, params.projectId);
    return {
      items: osStore.getDbFeeds(params.projectId),
      deployment: osStore.getDeployFeeds(params.projectId),
      note: "Observation feeds for Current State DATABASE + DEPLOYMENT — distinct from Atlas persistence.",
    };
  });
}
