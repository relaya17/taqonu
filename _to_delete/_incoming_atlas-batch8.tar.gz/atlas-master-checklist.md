# Atlas — רשימת מצב מאוחדת (Master Checklist)

תאריך: 19.08.2026. מסמך אחד, קצר, שמרכז את כל מה שאומת בפועל בסשן הזה — כדי שלא נאבד שום דבר בין המסמכים הארוכים. לפרטים/הוכחות file:line: `atlas-gap-analysis.md` ו-`atlas-security-intelligence-audit.md`.

## 1. רכיבי מערכת — האם קיימים בקוד

| רכיב | מצב |
|---|---|
| Atlas Core | ✅ קיים |
| Memory / Knowledge / Provenance | ✅ קיים, מהחזקים — אבל provenance (מי אימת) חסר |
| Agent Registry / Orchestrator | ✅ קיים (registry+lifecycle אמיתי; orchestrator dispatch עדיין specialists שהם stubs) |
| Automation Engine | ✅ קיים (3 חוקים, idempotency אמיתי, פעולה יחידה בכוונה: audit-log) |
| Event Bus | ✅ קיים (dedup אמיתי) |
| Risk Engine 0-100 | ⚠️ קיים אך לא נאכף בהיקף רחב — מחובר רק ב-`code.ts` אחד |
| Policy Engine | ⚠️ קיים אך חלקי — מחובר ל-~13 routes מתוך ~55 (agent-fabric dispatch + plugins.ts נוספו בסבב האחרון) |
| Universal Filter | ✅ קיים, מחובר ל-`/events` |
| Cost Intelligence | ✅ קיים, אמיתי (לא synthetic) |
| Anomaly Detection | ✅ קיים — z-score+IQR, כן עם `INSUFFICIENT_DATA` כשאין מספיק דגימות |
| Plugin SDK | ✅ קיים (data-only). **Sandbox להרצת קוד — לא נבנה בכוונה** |
| Marketplace UI | ✅ קיים |
| Command Center | ⚠️ קיים ברובו — 7 פאנלים (4 מקוריים + Plugins/Connections/Audit Log), עדיין לא מכסה כל route/feature (למשל: ניהול policy-engine coverage עצמו, RLS status, worker health מפורט) |
| CI/CD Gate | ✅ קיים וחוסם אמיתי — `process.exit(1)` על כשל, אימתתי בעצמי |
| Simulation/Preflight | ✅ קיים — חוסם `apply_patch`/`deploy` בפועל לפי risk |
| Multi-tenant / RLS | ⚠️ SQL אמיתי קיים (25+ policies), אך: (א) לא ניתן לאימות runtime מהסביבה הזו, (ב) הוא backstop — ההגנה העיקרית היא בדיקות ownerId ברמת ה-API |

## 2. 13 סעיפי האבטחה שביקשת (מצב אחרי כל התיקונים עד כה)

| # | סעיף | מצב |
|---|---|---|
| 1 | Authentication | ✅ EXISTS AND ENFORCED — תוקן: `auth.getUser()` אמיתי במקום decode-בלבד |
| 2 | Authorization (`authorizeEntityAction`) | ⚠️ PARTIAL — ~13/55 routes (agent-fabric dispatch + plugins.ts נוספו); עדיין לא ברוב ה-routes |
| 3 | Project ownership | ⚠️ PARTIAL — אכוף ב-~10 routes, לא בכולם |
| 4 | Memory ownership | ✅ EXISTS AND ENFORCED — תוקן אתמול (agent-fabric/conversation/qa) |
| 5 | Connections authorization | ⚠️ PARTIAL — auth תקין, policy/risk לא |
| 6 | Memory secret redaction | ⚠️ PARTIAL — נתיב עיקרי + agent.ts תוקנו; 2 נתיבים נמוכי-סיכון עדיין לא |
| 7 | FACT verification | ⚠️ PARTIAL — ה-cap אכוף; `approveMemory()` עדיין בלי דרישת evidence |
| 8 | Risk enforcement | ⚠️ EXISTS BUT NOT ENFORCED רחבות |
| 9 | Policy enforcement | ⚠️ EXISTS BUT NOT ENFORCED רחבות (`assertAuthorized` קוד מת) |
| 10 | Worker failure handling | ✅ EXISTS AND ENFORCED |
| 11 | Audit actor identity | ⚠️ PARTIAL — אמיתי ב-~8 routes, null בשאר |
| 12 | Health checks | ⚠️ PARTIAL, כנה — DB+LLM אמיתי, worker מדווח UNKNOWN (לא מזויף) |
| 13 | Tenant isolation | ✅ השתפר משמעותית אתמול — 6 דליפות אמיתיות נסגרו; RLS עדיין רק backstop |

## 3. תוקן אתמול בפועל (6 P0, מאומת: 448/448 בדיקות, build נקי)

1. עקיפת Authentication (החמור מכולם)
2. `agent-fabric.ts` — דליפת memory + חסר auth
3. `agent.ts` — אותה דליפה + באג redaction (secrets)
4. `conversation.ts`+`qa.ts` — 5 endpoints חסרי-auth
5. `GET /events` — public לגמרי → `requireAdmin`
6. `POST /memory/:id/approve` — IDOR
7. `decisions.ts` — חסר auth + epistemicState לא capped

## 4. עדכון — 3 מתוך 6 הפערים תוקנו עכשיו (מאומת: 458/458 בדיקות apps/api + 277/277 agent-core + 85/85 shared, build נקי בכל 3 החבילות)

1. ✅ **תוקן** — `agent-fabric.ts`'s `/agents/dispatch` עכשיו עובר `authorizeEntityAction("CONFIGURATION","EXECUTE")` (אותו pattern כמו `kernel.ts`). `/agents/plan` נשאר בלי (רק מציע תוכנית, לא מבצע — עקבי עם `kernel.ts`'s `/kernel/plan`). **לא נוסף** ניקוד risk מספרי — הוסבר בקוד למה (אין signal לפני-הפעולה כמו ב-`code.ts`; ידרוש תכנון approval-workflow נפרד).
2. ✅ **תוקן** — `approveMemory()` דוחה עכשיו קידום ל-CONFIRMED כשאין evidence בכלל (400 `NO_EVIDENCE`, לא 404 מטעה).
3. ✅ **תוקן** — נוספו `verifiedBy`/`verifiedAt` ל-`memorySchema` (אופציונליים, לא שוברים תאימות), מתמלאים אמיתית ב-`approveMemory()`.
4. ✅ **תוקן** — `central-opinion.ts` ו-`memory-pipeline.ts`'s pattern-seeding עכשיו קוראים ל-`redactSecrets` לפני שמירה.
5. ⚠️ **לא ניתן לתיקון מכאן** — RLS לא ניתן לאימות מהסביבה הזו (אין חיבור DB חי, `SUPABASE_SERVICE_ROLE_KEY=replace-me`). זו מגבלת סביבה, לא באג בקוד.
6. ✅ **תוקן** — Command Center הורחב ב-3 פאנלים חדשים לפי החלטתך ("הכל"): **Plugins** (רשימה+אישור/דחייה/הפעלה/השבתה/הסרה, inline), **Connections** (סטטוס GitHub/תיקיה מקומית, חבר/נתק/סרוק), **יומן ביקורת** (טבלת unified audit עם סינון לפי actorId). ראו סעיף 4ג למטה.

## 4ב. עוד 3 תיקונים (המשך יזום, "מה שכן אפשר") — מאומת: 468/468 apps/api, build נקי

7. ✅ **תוקן** — `POST /auth/oauth/sync` היה סוג אחר של אותה עקיפת-auth: `body.accessToken` (קלט לקוח גולמי) נסמך על `atlas_role` בלי אימות חתימה → הסלמת הרשאות. עכשיו עובר `verifySupabaseAccessToken()` האמיתי (אותה פונקציה מתיקון האתמול), פלוס בדיקה ש-`sub` בטוקן תואם את המשתמש המסונכרן.
8. ✅ **תוקן** — 2 הבאגים ב-CI workflow (`e2e-critical-path.yml`) שדווחו ולא תוקנו: `SUPABASE_SERVICE_ROLE_KEY` שונה בחזרה ל-`"replace-me"` המדויק (כדי ש-`isLiveSupabase()` יזהה נכון offline), `ENCRYPTION_KEY`/`COOKIE_SECRET` שונו לערכים שאינם ה-example הידוע (`assertNotExampleSecrets()`). `NODE_ENV: production` נשאר בכוונה — הוא בוחן התנהגות production-only אמיתית (Secure cookie flag, הסתרת password-reset token).
9. ✅ **תוקן** — `plugins.ts`'s 6 routes מוטציה (register/approve/reject/enable/disable/uninstall) קיבלו `authorizeEntityAction("CONFIGURATION", CREATE/UPDATE/DELETE)` בנוסף ל-`requireAdmin` הקיים — היו לגמרי בלי policy engine קודם.

## 4ג. Command Center — 3 פאנלים חדשים + תיקון אבטחה שנמצא אגב הבנייה (מאומת: 474/474 apps/api, `tsc --noEmit` נקי + `pnpm build` נקי ב-apps/web)

10. ✅ **נבנה** — `PluginsPanel.tsx`: טבלת פלאגינים עם approve/reject/enable/disable/uninstall inline (קורא ל-6 ה-routes הקיימים ב-`plugins.ts`), קישור ל-`/admin/marketplace` לניהול מלא.
11. ✅ **נבנה** — `ConnectionsPanel.tsx`: סטטוס חיבור GitHub + תיקיה מקומית, connect/disconnect/scan inline (קורא ל-`connections.ts`), קישור ל-`/he/integrations` לייבוא ריפוזיטוריז מלא.
12. ✅ **נבנה** — `AuditLogPanel.tsx`: טבלת unified audit log (WHO/WHAT/WHEN/WHY/POLICY/RISK/APPROVAL/RESULT) עם סינון לפי actorId.
13. 🔴 **תיקון אבטחה שנמצא אגב הבנייה** — `GET /api/v1/audit` היה **ציבורי לגמרי, בלי auth בכלל** — כל יומן הביקורת של כל הדיירים היה קריא לכל אחד. נוסף `requireAdmin` (אותה מחלקת באג כמו `GET /events` בסבב הקודם). בנוסף: השדה `unified` (רשומות מסוננות דרך `listUnifiedAuditEntries()`, עם פרמטר `actorId`) נוסף ל-response — לא היה קיים קודם, ה-panel לא היה יכול לעבוד בלעדיו.
14. שלושת הפאנלים נוספו ל-`admin/page.tsx` כטאבים 8-10 ("פלאגינים"/"חיבורים"/"יומן ביקורת") — עודכן על ידי (לא סוכן), כדי למנוע קונפליקטים בקובץ המשותף.

## 4ד. הרחבת Policy Engine — סבב פעיל (לפי בחירתך: Authorization/Policy Engine + Risk Engine + audit actorId/redaction) — עבודה בעצמי, בלי סוכנים

**batch 1** (מאומת: 484/484 apps/api, build נקי):
- `billing.ts`: נוסף `authorizeEntityAction("FINANCIAL_TRANSACTION","CREATE")` ל-`/billing/credits/purchase` ו-`/billing/stripe/checkout` (ה-webhook נשאר בלי — הוא server-to-server עם אימות חתימה, לא פעולת משתמש). `/billing/plan` כבר היה מכוסה קודם.
- `connections.ts`: נוסף `authorizeEntityAction("CONFIGURATION", ...)` לכל 6 ה-routes המוטציה (github connect/disconnect/import, local connect/disconnect/scan).

**batch 2** (מאומת: 495/495 apps/api, build נקי):
- 🔴 **תיקון אבטחה** — `POST /api/v1/memory` היה **ציבורי לגמרי, בלי auth** — כל אחד יכול היה להזריק זיכרון מפוברק ל-bucket המשותף (memory poisoning, בדיוק הסיכון שהוגדר במסמך המקורי). נוסף `requireSignedInForWrite` + `authorizeEntityAction("RECORD","CREATE")`.
- 🔴 **תיקון אבטחה** — `GET /api/v1/evidence` (ציבורי לגמרי — כל הראיות של כל הדיירים) ו-`POST /api/v1/evidence` (הזרקה אנונימית) — נוסף `requireUser`/`requireSignedInForWrite` + `authorizeEntityAction("DOCUMENT","CREATE")`. **הערה**: `requireUser` ולא `requireAdmin` — כי GET evidence מזין את DecisionsPanel בדשבורד הרגיל של כל משתמש (לא רק admin); `requireAdmin` היה שובר את זה.
- 🔴 **תיקון אבטחה** — `POST /api/v1/projects/:id/cloud` היה **בלי auth/ownership check בכלל** — כל אחד יכול היה לטריגר cloud-sync לכל project id (צריכת quota של בעלים אחר + חשיפת נתוני פרויקט). נוסף `assertProjectWriteAccess` + `authorizeEntityAction("RECORD","UPDATE")`. גם `PUT /:id/workspace-root` ו-`POST /projects` (create) קיבלו את שער ה-entity-policy (auth כבר היה קיים בהם).
- 🟡 **תיקון תשתית-בדיקות (לא אבטחה, אבל מצא בדרך)** — `memory-pipeline.test.ts` היה חסר בידוד `osStore` (בניגוד לכל קובץ בדיקה אחר בקוד) — זה גרם לו לזהם בפועל את `.atlas/store.json` האמיתי בכל הרצה, מה שגרם ל-5 בדיקות להיכשל אחרי כמה הרצות מצטברות היום. תוקן לפי אותו pattern שכל שאר קבצי הבדיקה משתמשים בו (tmp dir מבודד).
- ⚠️ **נמצא, לא תוקן** — עוד ~10 קבצי בדיקה בקוד חסרים אותו בידוד (`identity-reconcile.test.ts`, `plan-quota.test.ts`, `stripe.test.ts` ועוד) — לא גרמו לכשל היום, לא בטוח שיגרמו בעתיד, אבל זו סכנה סמויה דומה. סומן כ-follow-up, לא בטיפול בסבב הזה (מחוץ ל-3 הכיוונים שבחרת).

**batch 3** (מאומת: 498/498 apps/api, build נקי):
- `qa.ts`: נוסף `enforceQaEntityAuthz` — `/qa/learn` (POST+DELETE) → `CONFIGURATION.UPDATE`, `/qa/runs` + `/qa/process-audit` → `RECORD.EXECUTE`. auth כבר היה קיים; רק שער entity-policy נוסף. + בדיקת DENIED→403 ל-`/qa/learn`.
- `decisions.ts`: נוסף `enforceDecisionEntityAuthz` — `POST /decisions` → `RECORD.CREATE`, `POST /decisions/:id/transition` → `RECORD.UPDATE`. auth כבר היה קיים. (בדיקת wiring חדשה לא נוספה הפעם — תיעדוף פרגמטי של רוחב הכיסוי).
- `agent-lifecycle.ts`: נוסף `enforceAgentLifecycleEntityAuthz` (`CONFIGURATION.UPDATE`) ל-`/agents/:id/enable` ו-`/disable`.
- `approvals.ts`: נוסף שער `CONFIGURATION.EXECUTE` ל-`POST /approvals/:id/decide`. הערה חשובה בקוד: `mode:"APPROVE"` שמור ותמיד DENIES (״APPROVE is a human gate, not an entity-action-execution mode״) — ה-route הזה משתמש ב-`mode:"WRITE"`, לא ב-`"APPROVE"`.
- 🔴 **תיקון אבטחה** — `artifacts.ts`: `POST /api/v1/artifacts` (העלאת artifact) ו-`POST /api/v1/assists/runs` (הרצת AI-assist שצורכת קרדיטים) היו **שני routes בלי auth בכלל** — כל אחד יכול היה להעלות artifacts (צריכת אחסון) או לצרוך קרדיטים אנונימית, בלי ייחוס. נוסף `requireSignedInForWrite` + `enforceArtifactEntityAuthz` (`DOCUMENT.CREATE` / `RECORD.EXECUTE` בהתאמה). + 2 בדיקות 401 חדשות.

**batch 4** (מאומת: 516/516 apps/api, build נקי):
- 🔴 **תיקון אבטחה** — `commercial.ts`: `POST /onboarding/connect-repo`, `POST /onboarding/import` (כל 3 הענפים: local/github/remote) ו-`POST /partners/audit-spine` — **כל ה-3 routes היו בלי auth בכלל**. onboarding אפשר לכל אחד לרשום project לא-בבעלות (כולל קריאת נתיב filesystem שרירותי מהשרת); audit-spine הריץ audit מלא נגד כל project id בלי בדיקת בעלות. נוסף `requireSignedInForWrite` לשני ה-onboarding routes (עם `bindProjectOwner` אחרי יצירת הפרויקט בכל branch), `assertProjectWriteAccess` ל-audit-spine, ועוד `enforceCommercialEntityAuthz` (`RECORD.CREATE`/`RECORD.EXECUTE`) לכולם. קובץ בדיקה חדש `commercial.test.ts` (8 בדיקות) נכתב מאפס.
- 🔴 **תיקון אבטחה** — `conflicts.ts`: **דליפה חוצת-דיירים מלאה** — `GET /api/v1/conflicts` היה בלי auth וסרק כל project בכל tenant בלי סינון, מחזיר את כל ה-claims/conflicts של כולם. גם `POST /:id/suggest` וגם `POST /:id/resolve` היו בלי auth/ownership check. נוסף `requireUser` + סינון `canReadProjectScoped` ל-2 ה-GET/suggest routes, ו-`requireSignedInForWrite` + `assertProjectWriteAccess` (אחרי איתור ה-project הבעלים דרך סריקה, כי conflict id לא חושף project id ישירות) + `authorizeEntityAction("RECORD","UPDATE")` ל-resolve. קובץ בדיקה חדש `conflicts.test.ts` (10 בדיקות) נכתב מאפס, כולל seeding מלא של `ProjectStateSnapshot`+`Claim`ים דרך `osStore.claims`/`osStore.setSnapshot`.

**batch 5** (מאומת: 534/534 apps/api, build נקי):
- `conversation.ts`: נוסף שער `RECORD.EXECUTE` ל-`POST /conversation/message` (auth כבר היה קיים). `GET /conversation/threads/:id` **נשאר ללא auth בכוונה** — החלטה מפורשת שכבר תועדה בבדיקה קיימת (threadId הוא UUID אקראי לא-ניחוש, "informational read") — לא הפכתי החלטה קודמת שכבר התקבלה.
- 🔴 **תיקון אבטחה** — `db-feeds.ts` + `deploy-feeds.ts`: ה-GET routes (`/feeds/:projectId`, `/feeds/:projectId/deployment`) היו **בלי auth בכלל** — כל אחד שידע project id יכול היה לקרוא סכימת DB/deployment metadata של כל tenant. נוסף `assertProjectReadAccess`. גם נוסף שער `CONFIGURATION.CREATE` ל-4 ה-POST routes (auth/ownership כבר היה קיים בהם דרך `assertProjectWriteAccess`). קבצי בדיקה חדשים לשניהם (9+9 בדיקות).

**batch 6** (מאומת: 545/545 apps/api, build נקי):
- `provider-adapters.ts`: נוסף שער `CONFIGURATION.CREATE` ל-2 ה-observe routes (auth כבר היה קיים). קובץ בדיקה חדש (7 בדיקות).
- 🔴 **תיקון אבטחה** — `security-sarif.ts`: `POST /security/sarif` היה **בלי auth בכלל** — כל אחד יכול היה להזריק תוכן SARIF שרירותי (attacker-controlled) כראיית SECURITY מתויגת FACT לכל project id (evidence poisoning). נוסף `assertProjectWriteAccess` + שער `DOCUMENT.CREATE`. קובץ בדיקה חדש (4 בדיקות).

**batch 7 — `engineering-loop.ts`** (מאומת: 563/563 apps/api, build נקי) — הקובץ המורכב ביותר עד כה, 12 routes:
- 🔴 **תיקון אבטחה חמור** — `POST /engineering/loop`, `POST /benchmarks/run`, `POST /proof/run` היו **בלי auth בכלל** — כל אחד (אנונימי!) יכול היה להפעיל ריצת engineering-loop/benchmark-suite/Atlas-Proof אמיתית (compute + קריאת workspaceRoot) נגד כל נתיב. נוסף: כשיש `projectId` → `assertProjectWriteAccess`; כשאין (ריצת פורטפוליו) → `requireSignedInForWrite` לפחות. + שער `RECORD.EXECUTE` (`enforceEngineeringLoopEntityAuthz`) לשלושתם.
- 🔴 **תיקון אבטחה** — `POST /engineering/loop/:id/approve` **היה עם sign-in אבל בלי בדיקת בעלות בכלל** — כל משתמש מחובר יכול היה לאשר (ו**להחיל בפועל שינויי קוד על דיסק** דרך `applyPatchFiles`!) loop run של tenant אחר. נוסף `assertProjectWriteAccess` ברגע שה-`existing.projectId` ידוע (אותה תבנית scan-then-authorize כמו ב-conflicts.ts) + שער entity.
- 🔴 **תיקון אבטחה** — `GET /engineering/loop` (רשימה) ו-`GET /engineering/loop/:id` היו **בלי auth בכלל** וחשפו loop runs (כולל userRequest וטקסט patch) של כל הדיירים ללא סינון. נוסף `requireUser` + סינון `canReadProjectScoped`.
- 🟡 **תוקן חלקית, נמצאה מגבלת data-model** — `GET /benchmarks/suites`, `POST /benchmarks/regression`, `GET /proof/status` היו גם הם בלי auth. נוסף `requireUser` (חוסם גישה אנונימית לגמרי) — אבל **לא ניתן לסנן per-tenant**: `AtlasEvalSuiteRun`/`RegressionReport` לא נושאים בכלל שדה owner/project בסכימה שלהם, ו-`proof/status` שומר slot גלובלי יחיד (`osStore` meta key `lastProofReport`) המשותף לכל המשתמשים ולא per-tenant. תיקון אמיתי דורש שינוי data-model (הוספת ownerId לסכימות + מפתח per-project ל-proof status) — **מחוץ לסקופ של הסבב הזה, מסומן ל-follow-up**.
- ללא שינוי בכוונה (public, ללא נתוני tenant): `POST /actions/classify` (סיווג טקסט stateless), `GET /benchmarks/tasks` (קטלוג eval מקומי סטטי), `GET /golden/project` (קונפיגורציית env גלובלית).
- קובץ בדיקה חדש `engineering-loop.test.ts` (18 בדיקות) — כיסוי גבולות auth/ownership/entity-gate לכל ה-routes שתוקנו.

**batch 8 — סבב סיום** (מאומת: 593/593 apps/api, build נקי) — עבר על כל שאר קבצי ה-routes ברשימה:
- `conversation.ts`: (כבר תועד ב-batch 5).
- 🔴 **תיקון אבטחה** — `state.ts`: `GET /projects/:id/state` (endpoint מרכזי — כל ה-Current State rollup: evidence+conflicts+snapshot) ו-`POST /state/reconcile` היו **בלי auth בכלל**. נוסף `assertProjectReadAccess`/`assertProjectWriteAccess` + שער `RECORD.UPDATE` ל-reconcile. קובץ בדיקה חדש (6 בדיקות).
- 🔴 **תיקון אבטחה** — `sentinel.ts`: `GET /projects/:id/sentinel` (ממצאי סריקת אבטחה — **דליפת פגיעויות** ישירה) היה בלי auth. 3 ה-POST routes (scan/propose/verify) כבר היו עם `assertProjectWriteAccess` — נוסף רק שער entity (`CASE.CREATE`/`CASE.EXECUTE`). קובץ בדיקה חדש (5 בדיקות).
- 🔴 **תיקון אבטחה** — `observer.ts`: 4 GET routes (`/projects/:id/observer`, `/observer/expected`, `/observer/snapshots`, `/observer/state`) היו בלי auth וחשפו ממצאי observer/snapshots לפי project id. נוסף `assertProjectReadAccess` (ל-`/observer/state` רק כש-projectId ניתן). 4 ה-routes המוטציה כבר היו עם auth — נוסף שער entity לכולם. קובץ בדיקה חדש (7 בדיקות).
- 🔴 **תיקון אבטחה** — `github.ts`: `POST /github/discover` (יצירת פרויקטים לא-בבעלות ממטא-דאטה שרירותי) ו-`POST /github/sync` (דחיפת מטא-דאטה GitHub ל-project id כלשהו) היו **בלי auth בכלל**. נוסף `requireSignedInForWrite`+`assertProjectWriteAccess` בהתאמה + שערי entity. `GET /github` נשאר ציבורי בכוונה (קונפיגורציית App גלובלית — יש דליפה קטנה ב-`installations` cross-tenant, **מסומנת ל-follow-up**, לא תוקנה: דורשת סינון project-scoped ב-`listGithubAppInstallations`). install/callback/webhooks לא נגעתי — מוגנים כבר ב-state חתום / חתימת webhook. קובץ בדיקה חדש (6 בדיקות).
- 🔴 **תיקון אבטחה** — `legal-media.ts`: `POST /legal-media/review` היה בלי auth — כשניתן projectId חשף את נתיב ה-workspace-root של הפרויקט + הריץ ביקורת קוד אמיתית שממצאיה חוזרים לכל קורא. נוסף `assertProjectReadAccess` (רק כש-projectId ניתן; `GET /sources` נשאר ציבורי — קטלוג סטטי).
- 🟡 **תוקן חלקית** — `experts.ts`: `POST /experts/review` ו-`POST /editor/brief` — כשניתן projectId קראו נתוני snapshot/decisions של הפרויקט בלי auth. נוסף `assertProjectReadAccess` (רק כש-projectId ניתן). `GET /experts`/`POST /experts/select` נשארו ציבוריים (קטלוג/utility stateless).
- ✅ **נבדק, הוחלט להשאיר כפי שהוא (public בכוונה)**: `metrics.ts` (endpoint גלובלי בסגנון Prometheus scrape, ללא נתוני tenant בסכימה), `eval.ts`/`eval-ci-gate.ts` (Atlas מבקר את עצמו על state גלובלי-מצטבר, לא per-tenant, ללא הזרקת תוכן שרירותי), `research.ts` (utility stateless נגד קטלוג allow-listed), `contact.ts` POST (טופס ליד ציבורי בכוונה — כבר עם `requireAdmin` על ה-GET), `auth.ts` (17 routes — כולם תשתית זהות/session/admin-user-management, לא ממופים ל-BusinessEntityType, כבר עם auth משלהם — MFA/session/password; ראה auth.test.ts).
- קבצי בדיקה חדשים: `state.test.ts` (6), `sentinel.test.ts` (5), `observer.test.ts` (7), `github.test.ts` (6). `experts.ts`/`legal-media.ts` לא קיבלו קובץ בדיקה חדש הפעם — תיעדוף פרגמטי, אותה גישה כמו `decisions.ts` ב-batch 3.

**זהו סוף רשימת ה-~26 קבצי ה-routes שנסקרו לרוחב Policy Engine widening. כל route file בקוד עבר עכשיו סקירה מפורשת** (או שער נוסף / auth תוקן, או הוחלט במפורש שהוא public בכוונה — לא נשאר קובץ שלא נבדק).

**follow-ups שנמצאו אך לא תוקנו (מחוץ לסקופ, לסבב הבא)**:
1. `AtlasEvalSuiteRun`/`RegressionReport` (engineering-loop.ts) חסרים ownerId/projectId בסכימה — אי אפשר לסנן per-tenant בלי שינוי data-model.
2. `proof/status` שומר slot גלובלי יחיד (`lastProofReport`) — לא per-tenant.
3. `github.ts`'s `GET /github` — רשימת `installations` חוצת-tenant (accountLogin וכו') — לא סונן.
4. ~10 קבצי בדיקה עדיין חסרי בידוד `osStore` (מ-batch 2, לא טופל).

**עדיין לא התחיל (שני הכיוונים הנוספים שבחרת)**:
- הרחבת Risk Engine המספרי (`computeActionRiskScore`/`bucketForRiskScore`) מעבר לנקודת החיבור היחידה שלו ב-`code.ts`.
- השלמת audit actorId אמיתי בכל ה-routes (כיום ~8 routes בלבד עם actorId אמיתי, השאר `null`).

זו עבודה מרובת-סבבים נוספת — לא התחלתי אותה הסבב הזה מסיבות זמן; מומלץ session נפרד.

## 5. מה נבדק והתברר שגוי (רשימות ישנות/חיצוניות שהופרכו)

- "Event Bus/Risk Engine/Automation Engine/Universal Filter/Cost Intelligence/Anomaly Detection/Plugin-Marketplace חסרים" — **לא נכון**, כולם קיימים (ראו טבלה 1).
- "gates.ts חסר auth guard" (דיווח סוכן קודם) — **לא נכון**, יש auth ו-actorId אמיתי.
- "Risk Engine מחובר ל-11 routes" (תיעוד קודם) — **לא מדויק** — הניקוד המספרי מחובר לקובץ אחד בלבד; 10 האחרים משתמשים רק במדיניות קטגורית.

---
*מסמך זה הוא תמצית. לכל טענה יש file:line מגובה ב-`atlas-gap-analysis.md` (מיפוי מלא) ו-`atlas-security-intelligence-audit.md` (audit אבטחה מלא + תיקונים).*
