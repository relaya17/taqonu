import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { AtlasError, uuidSchema } from "@atlas/shared";
import { authorizeEntityAction } from "@atlas/agent-core";
import { requireSignedInForWrite } from "../middleware/auth-guards.js";
import {
  assertProjectReadAccess,
  assertProjectWriteAccess,
} from "../services/project-access.js";
import {
  executeBugIngest,
  executeObserveCycle,
  putExpectedBehaviorModel,
  readObserverState,
} from "../services/observe-cycle.js";

/** ENTITY-LEVEL gate helper, same self-approved signed-in-human-write
 * pattern used across this round. */
function enforceObserverEntityAuthz(
  entityType: "RECORD" | "CONFIGURATION",
  action: "CREATE" | "UPDATE" | "EXECUTE",
  routeLabel: string,
): void {
  const entityAuthz = authorizeEntityAction(entityType, action, {
    mode: "WRITE",
    writeGateOpen: true,
    approved: true,
  });
  if (entityAuthz.decision !== "ALLOWED") {
    const reason =
      entityAuthz.decision === "DENIED"
        ? entityAuthz.reason
        : `${routeLabel} (${entityType}.${action}) was not ALLOWED.`;
    throw new AtlasError("FORBIDDEN", reason, { statusCode: 403 });
  }
}

export async function registerObserverRoutes(
  app: FastifyInstance,
): Promise<void> {
  app.post("/api/v1/observe/cycle", async (request, reply) => {
    await requireSignedInForWrite(app, request);
    enforceObserverEntityAuthz("RECORD", "EXECUTE", "observe.cycle");
    const result = executeObserveCycle({
      body: request.body,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return reply.send(result);
  });

  app.post("/api/v1/projects/:id/observe-cycle", async (request, reply) => {
    const projectId = uuidSchema.parse((request.params as { id: string }).id);
    await assertProjectWriteAccess(app, request, projectId);
    enforceObserverEntityAuthz("RECORD", "EXECUTE", "projects.observe-cycle");
    const body =
      typeof request.body === "object" && request.body
        ? { ...(request.body as Record<string, unknown>), projectId }
        : { projectId };
    const result = executeObserveCycle({
      body,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return reply.send(result);
  });

  app.get("/api/v1/projects/:id/observer", async (request) => {
    // SECURITY FIX (found while widening Policy Engine coverage): this
    // route had ZERO auth — anyone who knew a project id could read its
    // observer findings/risk state.
    const projectId = uuidSchema.parse((request.params as { id: string }).id);
    await assertProjectReadAccess(app, request, projectId);
    return readObserverState({
      projectId,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
  });

  app.get("/api/v1/projects/:id/observer/expected", async (request) => {
    // SECURITY FIX: same class of gap as the sibling GET above.
    const projectId = uuidSchema.parse((request.params as { id: string }).id);
    await assertProjectReadAccess(app, request, projectId);
    const state = readObserverState({
      projectId,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return {
      expected: state.expected,
      compare: state.expectedCompare,
      error: state.error,
    };
  });

  app.put("/api/v1/projects/:id/observer/expected", async (request, reply) => {
    const projectId = uuidSchema.parse((request.params as { id: string }).id);
    await assertProjectWriteAccess(app, request, projectId);
    enforceObserverEntityAuthz(
      "CONFIGURATION",
      "UPDATE",
      "projects.observer.expected",
    );
    const result = putExpectedBehaviorModel({
      projectId,
      body: request.body,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return reply.send(result);
  });

  app.get("/api/v1/projects/:id/observer/snapshots", async (request) => {
    // SECURITY FIX: same class of gap as the other observer GET routes.
    const projectId = uuidSchema.parse((request.params as { id: string }).id);
    await assertProjectReadAccess(app, request, projectId);
    const state = readObserverState({
      projectId,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return {
      items: state.snapshots,
      total: state.snapshots.length,
      error: state.error,
    };
  });

  app.get("/api/v1/observer/state", async (request) => {
    const q = z
      .object({
        projectId: uuidSchema.optional(),
        workspaceRoot: z.string().max(1000).optional(),
      })
      .parse(request.query);
    // SECURITY FIX: same class of gap as the other observer GET routes —
    // only gated when a projectId is given (workspaceRoot-only calls carry
    // no tenant data to leak).
    if (q.projectId) {
      await assertProjectReadAccess(app, request, q.projectId);
    }
    return readObserverState({
      projectId: q.projectId ?? null,
      workspaceRoot: q.workspaceRoot ?? null,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
  });

  app.post("/api/v1/observer/bugs", async (request, reply) => {
    await requireSignedInForWrite(app, request);
    enforceObserverEntityAuthz("RECORD", "CREATE", "observer.bugs");
    const result = executeBugIngest({
      body: request.body,
      envGoldenRoot: app.atlasEnv.ATLAS_GOLDEN_PROJECT_ROOT ?? null,
    });
    return reply.status(201).send(result);
  });
}
