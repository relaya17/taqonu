import type { FastifyInstance } from "fastify";
import { runLegalMediaReview } from "@atlas/code-intelligence";
import {
  VERIFIED_LEGAL_MEDIA_SOURCES,
  legalSourcesByRegion,
  uuidSchema,
} from "@atlas/shared";
import { z } from "zod";
import { osStore } from "../store/os-store.js";
import { assertProjectReadAccess } from "../services/project-access.js";

export async function registerLegalMediaRoutes(
  app: FastifyInstance,
): Promise<void> {
  app.get("/api/v1/legal-media/sources", async () => ({
    note: "Allow-listed government / university / official bodies only. Not legal advice.",
    items: VERIFIED_LEGAL_MEDIA_SOURCES,
    byRegion: legalSourcesByRegion(),
  }));

  app.post("/api/v1/legal-media/review", async (request) => {
    const body = z
      .object({
        projectId: uuidSchema.nullable().optional(),
      })
      .parse(request.body ?? {});

    // SECURITY FIX (found while widening Policy Engine coverage): this
    // route had ZERO auth — when a projectId was given it revealed the
    // project's local workspace root path and ran a real code review
    // against it, leaking findings to any caller who knew the project id.
    const projectId = body.projectId ?? null;
    if (projectId) {
      await assertProjectReadAccess(app, request, projectId);
    }
    const workspaceRoot = projectId
      ? (osStore.getWorkspaceRoot(projectId) ?? null)
      : null;

    const review = runLegalMediaReview({
      projectId,
      workspaceRoot,
    });

    app.atlasLogger.info("legal_media_review", {
      projectId,
      lawyerReadiness: review.lawyerReadiness,
      findings: review.findings.length,
    });

    return review;
  });
}
